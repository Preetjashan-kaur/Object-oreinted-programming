﻿
using MainProject;

int option = 0, tempComputerIndex = 0, copyIndex = 0, index = 0, computerIndex = 0, sn = 0;
bool checkingValue = false;
int passwordCounter = 2;
string brand;
string model;
double price = 0;
string password;

do
{
    try
    {
        Console.Write("Please enter the number of computer that you want to enter :");
        index = Convert.ToInt32(Console.ReadLine());
        if (index < 0)
            Console.WriteLine("Please Enter Valid Value");
    }
    catch (Exception e)
    {
        Console.WriteLine("Please Enter Valid Value");
        index = -1;
    }
} while (index < 0);

Computer[] computer = new Computer[index];
copyIndex = index;
do
{

    Console.WriteLine();
    Console.WriteLine();
    Console.WriteLine("----------------------------------------------------------");
    Console.WriteLine("|                                                        |");
    Console.WriteLine("| What do you want to do?                                |");
    Console.WriteLine("| 1. Enter new computers                                 |");
    Console.WriteLine("| 2. Change information of a computer                    |");
    Console.WriteLine("| 3. Display all computers by a specific brand           |");
    Console.WriteLine("| 4. Display all computers under a certain a price.      |");
    Console.WriteLine("| 5. Display all computers .                             |");
    Console.WriteLine("| 6. Quit                                                |");
    Console.WriteLine("|                                                        |");
    Console.WriteLine("----------------------------------------------------------");
    do
    {
        try
        {
            Console.Write("Please enter your choice  : ");
            option = Convert.ToInt32(Console.ReadLine());
            if (option < 0)
            {
                Console.WriteLine("choosen option must be positive");
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("choosen option must be valid");
            option = -1;
        }
    } while (option < 0);

    switch (option)
    {
        case 1:
            {
                bool flag = true;

                Console.Write("Please Enter password :");
                password = Console.ReadLine();

                while ((Computer.password != password))
                {
                    if (passwordCounter == -1)
                    {
                        flag = false;
                        break;
                    }
                    if (passwordCounter == 0)
                        Console.WriteLine("It's Last chance to enter password");
                    else
                        Console.WriteLine("You have only " + (passwordCounter) + " chances left");

                    passwordCounter--;
                    Console.Write("Please Enter password :");
                    Console.WriteLine();
                    Console.WriteLine("----------------------------------------------------------");
                    password = Console.ReadLine();
                }

                if (flag == true)
                {
                    do
                    {
                        if (computerIndex <= index)
                        {
                            try
                            {
                            k1:
                                Console.WriteLine();
                                Console.Write("How many computers do you want to add :");
                                tempComputerIndex = Convert.ToInt32(Console.ReadLine());
                                if (tempComputerIndex < 0)
                                    Console.WriteLine("Computer index must be positive");

                                if (tempComputerIndex > index)
                                {
                                    Console.WriteLine("Inventory of the computer should be under " + copyIndex + " !!");
                                    goto k1;
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Computer index must be valid");
                                tempComputerIndex = -1;
                            }
                        }
                        else
                        {
                            Console.WriteLine();
                            Console.WriteLine(" You cannot add more values inside computer inventory..");
                        }
                    } while (tempComputerIndex < 0);

                    char choice = 'N';
                    do
                    {
                        bool checkingIndex = false;
                        if (tempComputerIndex <= copyIndex)
                        {
                            if (copyIndex - 1 >= 0)
                            {
                                Console.WriteLine("You can insert " + (copyIndex) + " computers");
                                Console.WriteLine();
                                Console.WriteLine("----------------------------------------------------------");
                                Console.WriteLine(" Enter Computer Brand :");
                                brand = Console.ReadLine();
                                Console.WriteLine("----------------------------------------------------------");
                                Console.WriteLine(" Enter Computer Model :");
                                model = Console.ReadLine();
                                Console.WriteLine("----------------------------------------------------------");
                                do
                                {
                                    try
                                    {
                                        Console.WriteLine(" Enter Serial Number :");
                                        sn = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine("----------------------------------------------------------");
                                        if (sn < 0)
                                            Console.WriteLine("Serial Number must be positive");
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine("Serial Number must be positive");
                                        sn = -1;
                                    }
                                } while (sn < 0);

                                do
                                {
                                    try
                                    {
                                        Console.WriteLine(" Enter Computer Price :");
                                        price = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine("----------------------------------------------------------");

                                        if (price < 0)
                                            Console.WriteLine("price must be positive");
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine("price must be valid value");
                                        price = -1;
                                    }
                                } while (price < 0);

                                computer[computerIndex] = new Computer(brand, model, sn, price);
                                checkingValue = true;
                                computerIndex++;
                                copyIndex--;
                            }
                            else
                            {
                                Console.WriteLine("You cannot insert a Computer because inventory is full...");
                                break;
                            }
                            tempComputerIndex--;
                        }
                        else
                        {
                            if (copyIndex == 0)
                            {
                                checkingIndex = true;
                                Console.WriteLine("Inventory is full you cannot insert the data");
                            }
                            else
                                Console.WriteLine("you should enter inventory number under " + copyIndex);

                            break;
                        }
                        if (checkingIndex == true)
                            break;

                        Console.Write("Do you still want to continue press Y or y :");
                        choice = Convert.ToChar(Console.ReadLine());
                    } while (choice == 'Y' || choice == 'y');
                }
                break;
            }
        case 2:
            {
                bool flag = true;

                Console.Write("Please Enter password :");
                password = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("----------------------------------------------------------");
                while ((Computer.password != password))
                {
                    if (passwordCounter == -1)
                    {
                        flag = false;
                        break;
                    }
                    if (passwordCounter == 0)
                        Console.WriteLine("It's Last chance to enter password");
                    else
                        Console.WriteLine("You have only " + (passwordCounter) + " chances left");

                    passwordCounter--;
                    Console.Write("Please Enter password :");
                    password = Console.ReadLine();
                }

                if (flag && checkingValue)
                {
                    int getComputerIndex = 0, opt = 0;
                    int tempSn = 0, tempPrice = 0;
                    string tempBrand = "", tempModel = "";

                    for (int i = 0; i < computerIndex; i++)
                    {
                        Console.WriteLine("Computer index :" + i);
                    }

                    Console.WriteLine("Please Enter computer index");
                    getComputerIndex = Convert.ToInt32(Console.ReadLine());

                    if (getComputerIndex < computerIndex)
                    {
                        computer[getComputerIndex].showComputer(getComputerIndex);
                        do
                        {
                            Console.WriteLine();
                            Console.WriteLine("----------------------------------------------------------");
                            Console.WriteLine("| which information would like to change?                |");
                            Console.WriteLine("| 1. Brand                                               |");
                            Console.WriteLine("| 2. Model                                               |");
                            Console.WriteLine("| 3. SN                                                  |");
                            Console.WriteLine("| 4. Price                                               |");
                            Console.WriteLine("| 5. Quit                                                |");
                            Console.WriteLine("----------------------------------------------------------");
                            do
                            {
                                try
                                {
                                    opt = Convert.ToInt32(Console.ReadLine());

                                    if (opt < 0)
                                        Console.WriteLine("Entered value must be positive!!");
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine("Invalid inpit : !! Enter Again : ");
                                    opt = -1;
                                }
                            } while (opt < 0);


                            switch (opt)
                            {
                                case 1:
                                    {
                                        Console.WriteLine("Enter new brand :");
                                        tempBrand = Console.ReadLine();
                                        Console.WriteLine();
                                        Console.WriteLine("----------------------------------------------------------");
                                        computer[getComputerIndex].setBrand(tempBrand);
                                        Console.WriteLine("After Updating");
                                        Console.WriteLine();
                                        Console.WriteLine("----------------------------------------------------------");
                                        computer[getComputerIndex].showComputer(getComputerIndex);
                                        break;
                                    }
                                case 2:
                                    {
                                        Console.WriteLine("Enter new Model :");
                                        tempModel = Console.ReadLine();
                                        Console.WriteLine();
                                        Console.WriteLine("----------------------------------------------------------");
                                        computer[getComputerIndex].setBrand(tempModel);
                                        Console.WriteLine("After Updating");
                                        Console.WriteLine();
                                        Console.WriteLine("----------------------------------------------------------");
                                        computer[getComputerIndex].showComputer(getComputerIndex);
                                        break;
                                    }
                                case 3:
                                    {
                                        do
                                        {
                                            try
                                            {
                                                Console.WriteLine(" Enter Serial Number :");
                                                tempSn = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine();
                                                Console.WriteLine("----------------------------------------------------------");

                                                if (tempSn < 0)
                                                    Console.WriteLine("Serial Number must be positive");
                                            }
                                            catch (Exception e)
                                            {
                                                Console.WriteLine("Serial Number must be positive");
                                                tempSn = -1;
                                            }
                                        } while (tempSn < 0);

                                        computer[getComputerIndex].setSn(tempSn);
                                        Console.WriteLine("After Updating");
                                        Console.WriteLine();
                                        Console.WriteLine("----------------------------------------------------------");
                                        computer[getComputerIndex].showComputer(getComputerIndex);
                                        break;
                                    }
                                case 4:
                                    {
                                        do
                                        {
                                            try
                                            {
                                                Console.WriteLine(" Enter Computer Price :");
                                                tempPrice = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine();
                                                Console.WriteLine("----------------------------------------------------------");

                                                if (tempPrice < 0)
                                                    Console.WriteLine("price must be positive");
                                            }
                                            catch (Exception e)
                                            {
                                                Console.WriteLine("price must be valid value");
                                                tempPrice = -1;
                                            }
                                        } while (tempPrice < 0);

                                        computer[getComputerIndex].setPrice(tempPrice);
                                        Console.WriteLine("After Updating");
                                        computer[getComputerIndex].showComputer(getComputerIndex);
                                        break;
                                    }
                            }

                        } while (opt != 5);
                    }
                    else
                        Console.WriteLine("Entered Computer index should be under "+computerIndex+" !!");

                    
                }
                else
                {
                    Console.WriteLine("First Enter the Value in to the inventory ");
                    Console.WriteLine();
                    Console.WriteLine("----------------------------------------------------------");
                }
                break;
            }
        case 3:
            {
                bool checkingBrand=true;
                string tempBrand = "";
                if (checkingValue)
                {
                    Console.WriteLine();
                    Console.WriteLine("----------------------------------------------------------");
                    Console.WriteLine("Please Enter Brand name :");
                    tempBrand = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine("----------------------------------------------------------");
                    for (int i = 0; i < computerIndex; i++)
                    {
                        if (computer[i].getBrand() == tempBrand)
                        {
                            computer[i].showComputer();
                            checkingBrand= false;
                        }
                        
                    }
                    if(checkingBrand)
                        Console.WriteLine("There is no computer in the inventory related to this brand name.");
                }
                break;
            }
        case 4:
            {
                bool checkingPrice = true;
                int tempPrice = 0;
                if (checkingValue)
                {
                    Console.WriteLine("Please Enter Price :");
                    Console.WriteLine();
                    Console.WriteLine("----------------------------------------------------------");
                    do
                    {
                        try
                        {
                            Console.WriteLine(" Enter Computer Price :");
                            tempPrice = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine();
                            Console.WriteLine("----------------------------------------------------------");

                            if (tempPrice < 0)
                                Console.WriteLine("price must be positive");
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("price must be valid value");
                            tempPrice = -1;
                        }
                    } while (tempPrice < 0);

                    for (int i = 0; i < computerIndex; i++)
                    {
                        if (computer[i].getPrice() < tempPrice)
                        {
                            checkingPrice = false;
                            computer[i].showComputer();
                        }      
                    }
                    if (checkingPrice)
                        Console.WriteLine("There is no computer under price $" + tempPrice+".");
                }
                else
                {
                    Console.WriteLine("First Enter the Value in to the inventory ");
                    Console.WriteLine();
                    Console.WriteLine("----------------------------------------------------------");
                }
                break;
            }
        case 5:
            {
                int counter = 0;
                do
                {
                    computer[counter].showComputer(counter);
                    counter++;
                } while (computerIndex != counter);
                break;
            }
        case 6:
            {
                break;
            }
        default:
            {
                Console.WriteLine("Value must 1 to 5 !!!");

                break;
            }
    }
} while (option != 6);





